package com.hcl.events.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;


import com.hcl.events.entities.SpecialEvents;

public interface SpecialEventsRepo extends CrudRepository<SpecialEvents,String> {
	 public List<SpecialEvents> findAll();
}
