package com.hcl.events.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.events.entities.SpecialEvents;
import com.hcl.events.repo.SpecialEventsRepo;
@Service
public class SpecialEventsService
{
	@Autowired
	SpecialEventsRepo repo;

	public List<SpecialEvents> getEvents()
	{
		return  repo.findAll();
	}
	public SpecialEvents addEvents(SpecialEvents li)
	{
		return   repo.save(li);
	}
}
