package com.hcl.events.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.events.entities.User;
import com.hcl.events.repo.UserRepo;

@Service
public class UserService 
{
	@Autowired
	UserRepo repo;
	
	public User register(User user)
	{
		return repo.save(user);
	}
	
	public User login(User user)
	{
		User u1=null;
		User u2 = repo.findByUserNameAndPassword(user.getUserName(),user.getPassword());
	Optional<User>	optionalUser=Optional.of(u2);
		
	/* 1st if user in available it will return u1   
	 * 2nd if user methion wrong credentials then it will execute try block
	 * 3rd if data is not available it will return message through catch block
	 * 
	 * */
		try {
			u1=optionalUser.orElseThrow(()->new Exception("invalid credentials"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		return u1;
	}

}
