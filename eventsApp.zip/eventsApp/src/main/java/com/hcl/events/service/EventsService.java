package com.hcl.events.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.hcl.events.entities.Events;
import com.hcl.events.repo.EventsRepo;

@Service
public class EventsService {
	@Autowired
	EventsRepo repo;

	public List<Events> getEvents()
	{
		return  repo.findAll();
	}
	public Events addEvents(Events li)
	{
		return   repo.save(li);
	}
}
