package com.hcl.events.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;


import com.hcl.events.entities.Events;

public interface EventsRepo extends CrudRepository<Events,String> {

	 public List<Events> findAll();


}
