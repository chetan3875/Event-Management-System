package com.hcl.events.eventsController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.events.entities.User;
import com.hcl.events.service.UserService;
@CrossOrigin
@RestController
@RequestMapping("/user")
public class UserController 
{
	
	@Autowired
	UserService service;
	
	@PostMapping("/register")
	public ResponseEntity<User> register(@RequestBody User user)
	{
		User u1=service.register(user);
		return new ResponseEntity(u1,HttpStatus.OK);
	}
	
	@PostMapping("/login")
	public ResponseEntity<User> login(@RequestBody User user)
	{
		User u1=null;
		ResponseEntity re=null;
	 u1=service.login(user);
	 
	 if(u1!=null)
	 {
		 re=new ResponseEntity(u1,HttpStatus.OK);
	 }
	 else
	 {
		 re= new ResponseEntity("invalid User Credentials",HttpStatus.NOT_FOUND);
	 }
	 
		return re;
	}

}
