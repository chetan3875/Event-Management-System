package com.hcl.events.repo;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.hcl.events.entities.User;

public interface UserRepo extends CrudRepository<User,String>{



	public User findByUserNameAndPassword(String userName, String password);
}
