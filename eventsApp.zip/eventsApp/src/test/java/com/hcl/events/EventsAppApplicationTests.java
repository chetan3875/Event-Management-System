package com.hcl.events;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventsAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
